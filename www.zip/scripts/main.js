// JavaScript Document
$(document).ready(function() {
    $(".sty").click(function(){
		$("#infor1").slideToggle("slow");
		});
});